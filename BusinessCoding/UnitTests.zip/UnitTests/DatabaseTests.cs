﻿using Effort;
using System;
using System.Data.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AdministrationPanel.DatabaseEntityFramework;
using System.Data.Common;

namespace UnitTests
{
    [TestClass]
    public class DatabaseTests
    {
        private BusinessCodingModelContex _context;

        [TestInitialize]
        public void Initialize()
        {
            _context = new BusinessCodingModelContex();
        }

        [TestCleanup]
        public void Cleanup()
        {
            _context.Dispose();
        }

        [TestMethod]
        protected void TestOfTest()
        {
            int a = 5;
            int b = 4;
            int c = 9;

            Assert.AreEqual(c, a + b);
        }

        [TestMethod]
        protected void TestAddTOoUsers()
        {
            DbConnection connection = Effort.DbConnectionFactory.CreateTransient();

            using (var context = new BusinessCodingModelContex(connection))
            {
                context.Users.Add(new Users()
                {
                    UserID = 100,
                    Login = "test",
                    Password = "123",
                    Email = "test@com.pl",
                    ActivationDate = DateTime.Parse("2013-11-05 22:12:28.990"),
                    LastLogin = DateTime.Parse("2013-11-05 22:12:28.990")
                });
            }
        }

    }
}
